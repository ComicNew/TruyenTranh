package com.skyreds.truyentranh.until;

public class Link {
    /*UPDATE URL*/
    public static final String URL_HOMEPAGE = "http://truyenchon.com/";
    public static final String URL_MONTH = "http://truyenchon.com/the-loai?status=-1&sort=11";
    public static final String URL_WEEKEND = "http://truyenchon.com/the-loai?status=-1&sort=12";
    public static final String URL_DAY = "http://truyenchon.com/the-loai?status=-1&sort=13";
    public static final String URL_HOTTREND = "http://truyenchon.com/hot";
    public static final String URL_BOY = "http://truyenchon.com/truyen-con-trai";
    public static final String URL_GIRL = "http://truyenchon.com/truyen-con-gai";
    public static final String URL_THELOAI = "http://truyenchon.com/the-loai";
    public static final String URL_SEARCH = "http://truyenchon.com/the-loai?keyword=";

}
